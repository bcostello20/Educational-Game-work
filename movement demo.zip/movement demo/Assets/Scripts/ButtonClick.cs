﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ButtonClick : MonoBehaviour {

	public void MoveUp()
	{
		Transform myTransform = GetComponent<Transform>();
		myTransform.localPosition += Vector3.up;
	}

	public void MoveDown()
	{
		Transform myTransform = GetComponent<Transform> ();
		myTransform.localPosition += Vector3.down;
	}
}
